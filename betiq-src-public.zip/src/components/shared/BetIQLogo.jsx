'use client';

export default function BetIQLogo({ size = 40 }) {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 40 40"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      style={{ filter: 'drop-shadow(0 0 12px rgba(37,99,235,0.6))' }}
    >
      <path
        d="M5 3h16c4 0 6.5 1.8 7.5 4.5.8 2.2.4 4.5-1.2 6.2 2.2 1.4 3.3 3.6 2.8 6.3-.8 3.6-4 5.5-8.5 5.5H5V3z"
        fill="url(#lg1)"
      />
      <path d="M9.5 8.5h9.5c1.5 0 2.5.9 2.5 2.2s-1 2.2-2.5 2.2H9.5V8.5z" fill="#0C1829" />
      <path d="M9.5 17.5h10c2 0 3.2 1.1 3.2 2.8s-1.2 2.7-3.2 2.7H9.5v-5.5z" fill="#0C1829" />
      <rect x="11"   y="18.5" width="2.2" height="3.5" rx="0.5" fill="url(#tl1)" />
      <rect x="14.2" y="16.8" width="2.2" height="5.2" rx="0.5" fill="url(#tl1)" />
      <rect x="17.4" y="15"   width="2.2" height="7"   rx="0.5" fill="url(#tl1)" />
      <path d="M13 13 L28 5.5"  stroke="white" strokeWidth="2" strokeLinecap="round" />
      <path d="M23.5 4 L29 5.5 L27.5 11" stroke="white" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round" fill="none" />
      <defs>
        <linearGradient id="lg1" x1="5" y1="3" x2="32" y2="32" gradientUnits="userSpaceOnUse">
          <stop offset="0%"   stopColor="#2563EB" />
          <stop offset="60%"  stopColor="#1D4ED8" />
          <stop offset="100%" stopColor="#06B6D4" />
        </linearGradient>
        <linearGradient id="tl1" x1="0" y1="0" x2="0" y2="1" gradientUnits="objectBoundingBox">
          <stop offset="0%"   stopColor="#22D3EE" />
          <stop offset="100%" stopColor="#0891B2" />
        </linearGradient>
      </defs>
    </svg>
  );
}
